import Vue from 'vue'
import Movies from './movies.vue'

const movies = new Vue(Movies)

movies.$mount()