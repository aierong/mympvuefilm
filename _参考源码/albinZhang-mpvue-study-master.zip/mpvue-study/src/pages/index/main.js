import Vue from 'vue'
import Index from './index'

const index = new Vue(Index)

// 挂载当前页面
index.$mount();