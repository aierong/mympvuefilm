import Vue from 'vue'
import List from './list.vue'

const list = new Vue(List)

list.$mount()