import Vue from 'vue'
import MovieDetail from './movieDetail.vue'

const movieDetail = new Vue(MovieDetail)

movieDetail.$mount()