import Vue from 'vue'
import Detail from './detail.vue'

const detail = new Vue(Detail)

detail.$mount()