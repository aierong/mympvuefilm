export default{
    pageIndex:null, //标识 页面下标
    isPlay:false
}