export const RECEIVE_LIST = 'receive_list'
export const MOVIES_ARR = 'movies_arr'
